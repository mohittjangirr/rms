# Realtime face-recognition-on-browser using webcam

## Real-time face recognition on browser using face-api.js. You can add faces to recognize and this project will store the face descriptors in json file for future use.

## Requirements : 
   - PHP 5 or PHP 7
   - Functional Webcam
   - Browser (Google Chrome, Mozilla Firefox)

## Steps :
  	- Download the project.
  	- Extract the downloaded zip file.
 	- Since I am using apache linux, I placed all files in /var/www/html directory.
  	- Finish. You can now test the project by accessing http://localhost to your local browser.



###### For more info visit https://github.com/justadudewhohacks/face-api.js
